 

**************************************************************************
*                                                                        *
*                   Library Cell to Verilog New Hierarchy Creation Tool  *
*                 Copyright (c) 2012-2016, edautils.com                  *
*                                                                        *
**************************************************************************

Welcome to the free createhierarchy utility!  This utility
is meant for those designers who wants to insert a new hierarchy by clubbing
selected instances inside a verilog module given as top.

    Goto installation area and source the file 'setup_env.csh' to setup
the environment for this tool.


    Alternatively for Unix
    setenv EDAUTILS_ROOT /usr/user1/DesignPlayer-linux.x86/01MAY2014 ( this installation directory )
    set path = ( $EDAUTILS_ROOT/bin $path ) 

    And for Windows 

    set EDAUTILS_ROOT=D:\tmp\DesignPlayer-win32.x86_64\01MAY2014 ( this installation directory )
    set PATH="%path%;%EDAUTILS_ROOT%\bin"

    createhierarchy -in test.v -out test.v -instances inst1:inst2 -top mytop -new_hier_name myNewMod -new_hier_name u_newmod 
			OR
    java com.eu.miscedautils.verilogparser.CreateHierarchy -in test.v -out test.v -instances inst1:inst2 -top mytop -new_hier_name myNewMod -new_hier_name u_newmod



Examples
========
    You can get a better understanding of this tool by seeing the examples
in the 'examples' directory in the installation area.

License Setting
===============
    Set the EDAUTILS_LICENSE_FILE environment variable before running the tool.
    You may refer the page www.computerhope.com/issues/ch000549.htm to know howto set
    environment variables in Windows.

FEEDBACK
========
Send feedback/requirements to help@edautils.com

 
